﻿namespace Ej2Grid.Models;

public partial class OrderVM
{
    public Order order { get; set; }

    public string CustomerName { get; set; }
}
