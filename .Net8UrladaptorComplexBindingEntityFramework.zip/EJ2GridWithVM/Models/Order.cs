﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Ej2Grid.Models;

public partial class Order
{
    [Key]
    public int OrderId { get; set; }

    public string CustomerId { get; set; }

    public int? EmployeeId { get; set; }

    public decimal? Freight { get; set; }

    public DateTime? OrderDate { get; set; }

    public string ShipCity { get; set; }

    public string ShipCountry { get; set; }

    public bool? Checked { get; set; }
}
