﻿using System.ComponentModel.DataAnnotations;

namespace Ej2Grid.Models;

public partial class Customer
{
    [Key]
    public string CustomerId { get; set; }

    public string CustomerName { get; set; }
}
