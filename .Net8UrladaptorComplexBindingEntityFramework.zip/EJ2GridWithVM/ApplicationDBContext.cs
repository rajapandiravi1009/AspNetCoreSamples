﻿using Ej2Grid.Models;
using Microsoft.EntityFrameworkCore;

namespace EJ2Grid
{
    public class ApplicationDBContext: DbContext
    {
        public virtual DbSet<Order> Orders { get; set; }
        public virtual DbSet<Customer> Customers { get; set; }

        public ApplicationDBContext(DbContextOptions<ApplicationDBContext> options) : base(options)
        {

        }


    }
}
