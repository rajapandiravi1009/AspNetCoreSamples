﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using System.Collections;
using System.Data;
using Microsoft.Data.SqlClient;
using Syncfusion.EJ2.Base;
using System.Configuration;
using Microsoft.Extensions.Configuration;
using System.IO;
using Microsoft.AspNetCore.Hosting;
using static NuGet.Packaging.PackagingConstants;
using System.Diagnostics.Metrics;
using System.Net;
using WebApplication1.Models;
using Newtonsoft.Json;
using System.Data.Common;

namespace WebApplication1.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            List<object> data1 = new List<object>();
            data1.Add(new { positionName = "Usa", id = 1 });
            data1.Add(new { positionName = "France", id = 3 });
            data1.Add(new { positionName = "Austria", id = 3 });
            ViewBag.DropDownDataWRPositions = data1;
            List<object> data2 = new List<object>();
            data2.Add(new { positionName = "Switzerland", id = 4 });
            data2.Add(new { positionName = "Brazil", id = 5 });
            data2.Add(new { positionName = "Canada", id = 6 });
            ViewBag.DropDownDataTEPositions = data2;
            ViewBag.DataSource = CustomerData.GetAllRecords();
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddOrEdit(string gridData)
        {
            // Parse JSON string to get grid data

           

           var ingredients = JsonConvert.DeserializeObject<List<CustomerData>>(gridData);

            return PartialView("MasterAddPartial");

        }


        public ActionResult MasterAddPartial()
        {
            List<object> data = new List<object>();
            data.Add(new { Country = "Usa", id = 1 });
            data.Add(new { Country = "France", id = 3 });
            data.Add(new { Country = "Austria", id = 3 });
            data.Add(new { Country = "Switzerland", id = 4 });
            data.Add(new { Country = "Brazil", id = 5 });
            data.Add(new { Country = "Canada", id = 6 });
            ViewBag.datasource = data;
            return PartialView("MasterAddPartial");
        }
        public ActionResult MasterEditPartial([FromBody] ICRUDModel<MasterDialogTemplateModel> value)
        {
            List<object> data = new List<object>();
            data.Add(new { Country = "Usa", id = 1 });
            data.Add(new { Country = "France", id = 3 });
            data.Add(new { Country = "Austria", id = 3 });
            data.Add(new { Country = "Switzerland", id = 4 });
            data.Add(new { Country = "Brazil", id = 5 });
            data.Add(new { Country = "Canada", id = 6 });
            ViewBag.datasource = data;
            return PartialView("MasterEditPartial", value.value);
        }


        public IActionResult MasterUrlDatasource([FromBody] DataManagerRequest dm)
        {
            IEnumerable DataSource = CustomerData.GetAllRecords();
            DataOperations operation = new DataOperations();
            if (dm.Search != null && dm.Search.Count > 0)
            {
                DataSource = operation.PerformSearching(DataSource, dm.Search);  //Search
            }
            if (dm.Sorted != null && dm.Sorted.Count > 0) //Sorting
            {
                DataSource = operation.PerformSorting(DataSource, dm.Sorted);
            }
            if (dm.Where != null && dm.Where.Count > 0) //Filtering
            {
                DataSource = operation.PerformFiltering(DataSource, dm.Where, dm.Where[0].Operator);
            }
          
            int count = DataSource.Cast<CustomerData>().Count();
            if (dm.Skip != 0)
            {
                DataSource = operation.PerformSkip(DataSource, dm.Skip);   //Paging
            }
            if (dm.Take != 0)
            {
                DataSource = operation.PerformTake(DataSource, dm.Take);
            }
            //return dm.RequiresCounts ? Json(new { result = DataSource, count = count   }) : Json(DataSource);
            IEnumerable groupedData = null;
            if (dm.Group != null)
            {
                groupedData = operation.PerformGrouping<CustomerData>(DataSource, dm); // perform Grouping
            }
            return dm.RequiresCounts ? Json(new { result = (groupedData == null) ? DataSource : groupedData, groupDs = groupedData, count = count }) : Json(DataSource); // return the result and count object based on RequiresCounts property

        }
        public ActionResult MasterInsert([FromBody] ICRUDModel<CustomerData> value)
        {
            if (value.value.CustomerID == null)
            {
                // Exception is thrown when ‘OrderID’ is empty
                throw new Exception("Cannot insert row CustomerID is empty");
            }

            CustomerData.GetAllRecords().Insert(0, value.value);
            
            return Json(value.value);
        }
        public ActionResult MasterUpdate([FromBody] ICRUDModel<CustomerData> value)
        {
            var cdt = value.value;
            CustomerData val = CustomerData.GetAllRecords().Where(cd => cd.CustomerID == cdt.CustomerID).FirstOrDefault();
            val.CustomerID = cdt.CustomerID;
            val.ContactName = cdt.ContactName;
            val.CompanyName = cdt.CompanyName;
            val.Address = cdt.Address;
            val.Country = cdt.Country;

            return Json(value.value);
        }

        public ActionResult MasterDelete([FromBody] ICRUDModel<CustomerData> value)
        {
            CustomerData.GetAllRecords().Remove(CustomerData.GetAllRecords().Where(cd => cd.CustomerID == value.key.ToString()).FirstOrDefault());
            return Json(value);
        }


        public IActionResult DetailUrlDatasource([FromBody] DataManagerRequest dm)
        {
            IEnumerable DataSource = OrdersDetails.GetAllRecords();
            DataOperations operation = new DataOperations();
            if (dm.Search != null && dm.Search.Count > 0)
            {
                DataSource = operation.PerformSearching(DataSource, dm.Search);  //Search
            }
            if (dm.Sorted != null && dm.Sorted.Count > 0) //Sorting
            {
                DataSource = operation.PerformSorting(DataSource, dm.Sorted);
            }
            if (dm.Where != null && dm.Where.Count > 0) //Filtering
            {
                DataSource = operation.PerformFiltering(DataSource, dm.Where, dm.Where[0].Operator);
            }
            int count = DataSource.Cast<OrdersDetails>().Count();
            if (dm.Skip != 0)
            {
                DataSource = operation.PerformSkip(DataSource, dm.Skip);   //Paging
            }
            if (dm.Take != 0)
            {
                DataSource = operation.PerformTake(DataSource, dm.Take);
            }
            return dm.RequiresCounts ? Json(new { result = DataSource, count = count }) : Json(DataSource);
        }
        public ActionResult DetailInsert([FromBody] ICRUDModel<OrdersDetails> value)
        {
            OrdersDetails.GetAllRecords().Insert(0, value.value);
            return Json(value.value);
        }
        public ActionResult DetailUpdate([FromBody] ICRUDModel<OrdersDetails> value)
        {
            var ord = value.value;
            OrdersDetails val = OrdersDetails.GetAllRecords().Where(or => or.OrderID == ord.OrderID).FirstOrDefault();
            val.OrderID = ord.OrderID;
            val.CustomerID = ord.CustomerID;
            val.OrderDate = ord.OrderDate;
            val.ShippedDate = ord.ShippedDate;
            val.Freight = ord.Freight; ;
            val.ShipName = ord.ShipName;
            val.ShipAddress = ord.ShipAddress;
            val.ShipCity = ord.ShipCity;
            val.ShipCountry = ord.ShipCountry;

            return Json(value.value);
        }

        public ActionResult DetailDelete([FromBody] ICRUDModel<OrdersDetails> value)
        {
            OrdersDetails.GetAllRecords().Remove(OrdersDetails.GetAllRecords().Where(or => or.OrderID == int.Parse(value.key.ToString())).FirstOrDefault());
            return Json(value);
        }



        public class ICRUDModel<T> where T : class
        {
            public string action { get; set; }

            public string table { get; set; }

            public string keyColumn { get; set; }

            public object key { get; set; }

            public T value { get; set; }

            public List<T> added { get; set; }

            public List<T> changed { get; set; }

            public List<T> deleted { get; set; }

            public IDictionary<string, object> @params { get; set; }
        }


    public ActionResult DetailAddPartial()
        {

            List<object> data = new List<object>();
            data.Add(new { Country = "Usa", id = 1 });
            data.Add(new { Country = "France", id = 3 });
            data.Add(new { Country = "Austria", id = 3 });
            data.Add(new { Country = "Switzerland", id = 4 });
            data.Add(new { Country = "Brazil", id = 5 });
            data.Add(new { Country = "Canada", id = 6 });
            ViewBag.datasource = data;
            return PartialView("DetailAddPartial");
        }
        public ActionResult DetailEditPartial([FromBody] ICRUDModel<DetailDialogTemplateModel> value)
        {

            List<object> data = new List<object>();
            data.Add(new { Country = "Usa", id = 1 });
            data.Add(new { Country = "France", id = 3 });
            data.Add(new { Country = "Austria", id = 3 });
            data.Add(new { Country = "Switzerland", id = 4 });
            data.Add(new { Country = "Brazil", id = 5 });
            data.Add(new { Country = "Canada", id = 6 });
            ViewBag.datasource = data;
            return PartialView("DetailEditPartial", value.value);
        }
        public class CustomerData
        {

            public CustomerData() { 
            }
            public static List<CustomerData> customerData = new List<CustomerData>();
            public static List<CustomerData> GetAllRecords()
            {
                if (customerData.Count == 0)
                {
                    customerData.Add(new CustomerData()
                    {
                        CustomerID = "BLONP",
                        ContactName = "FrÃ©dÃ©rique Citeaux",
                        CompanyName = "Blondesddsl pÃ¨re et fils",
                        Address = "24, place KlÃ©ber",
                        Country = "France"
                    });
                    customerData.Add(new CustomerData()
                    {
                        CustomerID = "CHOPS",
                        ContactName = "FrÃ©dÃ©rique Citeaux",
                        CompanyName = "Chop-suey Chinese",
                        Address = "c. 29",
                        Country = "SWITZERLAND"
                    });
                    customerData.Add(new CustomerData()
                    {
                        CustomerID = "ERNSH",
                        ContactName = "Roland Mendel",
                        CompanyName = "Ernst Handel",
                        Address = "Kirchgasse 6",
                        Country = "Austria"
                    });
                }
                return customerData;
            }

            public CustomerData(string CustomerID, string ContactName, string CompanyName, string Address, string Country)
            {
                this.CustomerID = CustomerID;
                this.ContactName = ContactName;
                this.CompanyName = CompanyName;
                this.Address = Address;
                this.Country = Country;
            }
            public string CustomerID { get; set; }
            public string ContactName { get; set; }
            public string CompanyName { get; set; }
            public string Address { get; set; }
            public string Country { get; set; }
        }

    public class OrdersDetails
        {
            public static List<OrdersDetails> Orders = new List<OrdersDetails>();
            public static List<OrdersDetails> GetAllRecords()
            {
                if (Orders.Count() == 0)
                {
                    Orders.Add(new OrdersDetails()
                    {

                        OrderID= 10258,
                        CustomerID= "ERNSH",
                        OrderDate = new DateTime(1996, 07, 17),
                        ShippedDate = new DateTime(1996, 07, 13),
                        Freight= 140.51,
                        ShipName= "Ernst Handel",
                        ShipAddress= "Kirchgasse 6",
                        ShipCity= "Graz",
                        ShipCountry= "Austria"
                    });
                    Orders.Add(new OrdersDetails()
                    {
                        OrderID= 10263,
                        CustomerID= "ERNSH",
                        OrderDate= new DateTime(1996, 07, 23),
                        ShippedDate= new DateTime(1996, 07, 31),
                        Freight= 146.06,
                        ShipName= "Ernst Handel",
                        ShipAddress= "Kirchgasse 6",
                        ShipCity= "Graz",
                        ShipCountry= "Austria",
                    });
                    Orders.Add(new OrdersDetails()
                    {
                        OrderID= 10382,
                        CustomerID= "ERNSH",
                        OrderDate= new DateTime(1996, 12, 13),
                        ShippedDate= new DateTime(1996, 12, 16),
                        Freight= 94.77,
                        ShipName= "Ernst Handel",
                        ShipAddress= "Kirchgasse 6",
                        ShipCity= "Graz",
                        ShipCountry= "Austria"
                    });
                    Orders.Add(new OrdersDetails()
                    {
                        OrderID = 10436,
                        CustomerID = "BLONP",
                        OrderDate = new DateTime(1996, 02, 05),
                        ShippedDate = new DateTime(1996, 02, 11),
                        Freight = 156.66,
                        ShipName = "Blondel pÃ¨re et fils",
                        ShipAddress = "24, place KlÃ©ber",
                        ShipCity = "Strasbourg",
                        ShipCountry = "France"
                    });
                    Orders.Add(new OrdersDetails()
                    {
                        OrderID = 10265,
                        CustomerID = "BLONP",
                        OrderDate = new DateTime(1996, 07, 25),
                        ShippedDate = new DateTime(1996, 08, 12),
                        Freight = 55.28,
                        ShipName = "Blondel pÃ¨re et fils",
                        ShipAddress = "24, place KlÃ©ber",
                        ShipCity = "Strasbourg",
                        ShipCountry = "France"
                    });
                    Orders.Add(new OrdersDetails()
                    {
                        OrderID = 10297,
                        CustomerID = "BLONP",
                        OrderDate = new DateTime(1996, 09, 04),
                        ShippedDate = new DateTime(1996, 09, 10),
                        Freight = 5.74,
                        ShipName = "Blondel pÃ¨re et fils",
                        ShipAddress = "24, place KlÃ©ber",
                        ShipCity = "Strasbourg",
                        ShipCountry = "France"
                    });
                    Orders.Add(new OrdersDetails()
                    {
                        OrderID = 10254,
                        CustomerID = "CHOPS",
                        OrderDate = new DateTime(1996, 07, 11),
                        ShippedDate = new DateTime(1996, 07, 23),
                        Freight = 22.98,
                        ShipName = "Chop-suey Chinese",
                        ShipAddress = "Hauptstr. 31",
                        ShipCity = "Berlin",
                        ShipCountry = "Switzerland"
                    }); 
                    Orders.Add(new OrdersDetails()
                    {
                        OrderID = 10370,
                        CustomerID = "CHOPS",
                        OrderDate = new DateTime(1996, 12, 03),
                        ShippedDate = new DateTime(1996, 12, 27),
                        Freight = 1.17,
                        ShipName = "Chop-suey Chinese",
                        ShipAddress = "Hauptstr. 31",
                        ShipCity = "Berlin",
                        ShipCountry = "Switzerland"
                    });
                }
                return Orders;
            }

            public int OrderID { get; set; }
            public string CustomerID { get; set; }
            public DateTime OrderDate { get; set; }
            public DateTime ShippedDate { get; set; }
            public double Freight { get; set; }
            public string ShipName { get; set; }
            public string ShipAddress { get; set; }
            public string ShipCity { get; set; }
            public string ShipCountry { get; set; }
        }
    }
}

