﻿using Microsoft.AspNetCore.Razor.TagHelpers;
using Newtonsoft.Json;
using Syncfusion.EJ2;
namespace ASPCore.Pages
{
    [HtmlTargetElement("SyncButton")]
    public class SyncButton : Syncfusion.EJ2.Buttons.Button
    {
        public string className = "e-control e-btn";

        public ButtonStyles Styles { get; set; }

        public enum ButtonStyles
        {
            Basic,
            Success,
            Info,
            Warning,
            Danger
        }

        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            output.TagName = "button";
            output.TagMode = TagMode.StartTagAndEndTag;
            output.Content.SetContent(Content);
            if (Disabled)
            {
                output.Attributes.SetAttribute("disabled", Disabled);
            }
            if (IsPrimary)
            {
                className += " e-primary";
            }
            else if (Styles == ButtonStyles.Success)
            {
                className += " e-success";
            }
            else if (Styles == ButtonStyles.Info)
            {
                className += " e-info";
            }
            else if (Styles == ButtonStyles.Warning)
            {
                className += " e-warning";
            }
            else
            {
                className += " e-danger";
            }
            output.Attributes.SetAttribute("Class", className);
        }
    }
    [HtmlTargetElement("rei-ejs-grid")]
    public class ReiEjsGridTagHelper : TagHelper
    {
        public bool AllowFiltering { get; set; } = true;
        public bool AllowSorting { get; set; } = true;
        public object GridData { get; set; }
        public string CssClass { get; set; } = "rei-ejs-grid";
        public string ID { get; set; } = "grid";

        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            output.TagName = "div"; // Container for ejs-grid
            output.Attributes.SetAttribute("id", ID);

            // Serializing GridData for use in JavaScript
            var serializedData = GridData != null ? JsonConvert.SerializeObject(GridData) : "[]";

            // Inject the ejs-grid markup and JavaScript initialization code
            output.Content.SetHtmlContent($@"
            <script>
                document.addEventListener('DOMContentLoaded', function() {{
                    var grid = document.getElementById('{ID}');
                    new ej.grids.Grid({{
                        allowFiltering: {AllowFiltering.ToString().ToLower()},
                        allowSorting: {AllowSorting.ToString().ToLower()},
                        dataSource: {serializedData},
                        cssClass: '{CssClass}'
                    }}).appendTo(grid);
                }});
            </script>
        ");
        }

    }
}

