﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ASPCORE.Pages
{
    public class PrivacyModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}