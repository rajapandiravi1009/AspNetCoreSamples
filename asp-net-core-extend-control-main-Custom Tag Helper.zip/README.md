# How to add extend control in ASP.NET Core application?

This sample explains that how to add extend control in ASP.NET Core application.

## Prerequisites

Visual Studio 2022

## How to run this application?

* Checkout this project to a location in your disk.
* Open the solution file using the Visual Studio 2022.
* Restore the NuGet packages by rebuilding the solution.
* Run the project.