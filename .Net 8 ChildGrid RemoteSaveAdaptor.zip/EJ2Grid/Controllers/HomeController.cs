﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using EJ2Grid.Models;
using Syncfusion.EJ2.Base;
using System.Collections;
using System.ComponentModel.DataAnnotations;
using static EJ2Grid.Controllers.HomeController;

namespace EJ2Grid.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            var order = OrdersDetails.GetAllRecords();
            ViewBag.datasource = order.ToArray();
            var childdata = Child.GetAllRecords();
            ViewBag.child = childdata.ToArray();
            return View();
        }

        public ActionResult Update([FromBody] CRUDModel<OrdersDetails> value)
        {
            var ord = value.Value;
            OrdersDetails val = OrdersDetails.GetAllRecords().Where(or => or.OrderID == ord.OrderID).FirstOrDefault();
            val.OrderID = ord.OrderID;
            val.EmployeeID = ord.EmployeeID;
            val.CustomerID = ord.CustomerID;
            val.Freight = ord.Freight;
            val.OrderDate = ord.OrderDate;
            val.ShipCity = ord.ShipCity;

            return Json(value.Value);
        }
        //insert the record
        public ActionResult Insert([FromBody] CRUDModel<OrdersDetails> value)
        {

            OrdersDetails.GetAllRecords().Insert(0, value.Value);
            return Json(value.Value);
        }
        //Delete the record
        public ActionResult Delete([FromBody] CRUDModel<OrdersDetails> value)
        {
            OrdersDetails.GetAllRecords().Remove(OrdersDetails.GetAllRecords().Where(or => or.OrderID == int.Parse(value.Key.ToString())).FirstOrDefault());
            return Json(value);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Updatechild([FromBody] CRUDModel<Child> value)
        {
            var ord = value.Value;
            Child val = Child.GetAllRecords().Where(or => or.OrderID == ord.OrderID).FirstOrDefault();
            val.OrderID = ord.OrderID;
            val.EmployeeID = ord.EmployeeID;
            val.FirstName = ord.FirstName;
            val.LastName = ord.LastName;

            return Json(value.Value);
        }
        //insert the record
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Insertchild([FromBody] CRUDModel<Child> value)
        {

            Child.GetAllRecords().Insert(0, value.Value);
            return Json(value.Value);
        }
        //Delete the record
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Deletechild([FromBody] CRUDModel<Child> value)
        {
            Child.GetAllRecords().Remove(Child.GetAllRecords().Where(or => or.OrderID == int.Parse(value.Key.ToString())).FirstOrDefault());
            return Json(value);
        }



        public class OrdersDetails
        {
            public static List<OrdersDetails> order = new List<OrdersDetails>();
            public OrdersDetails()
            {

            }
            public OrdersDetails(int OrderID, string CustomerId, string UserID, int EmployeeId, double Freight, bool Verified, DateTime OrderDate, string ShipCity, string ShipName, string ShipCountry, DateTime ShippedDate, string ShipAddress)
            {
                this.OrderID = OrderID;
                this.CustomerID = CustomerId;
                this.UserID = UserID;
                this.EmployeeID = EmployeeId;
                this.Freight = Freight;
                this.ShipCity = ShipCity;
                this.Verified = Verified;
                this.OrderDate = OrderDate;
                this.ShipName = ShipName;
                this.ShipCountry = ShipCountry;
                this.ShippedDate = ShippedDate;
                this.ShipAddress = ShipAddress;
            }
            public static List<OrdersDetails> GetAllRecords()
            {
                if (order.Count() == 0)
                {
                    int code = 10000;
                    for (int i = 1; i < 2; i++)
                    {
                        order.Add(new OrdersDetails(code + 1, "ALFKI", "111", 1, 2.3 * i, false, new DateTime(1991, 05, 15), "Berlin", "Simons bistro", "Denmark", new DateTime(1996, 7, 16), "Kirchgasse 6"));
                        order.Add(new OrdersDetails(code + 2, "ANATR", "222", 2, 3.3 * i, true, new DateTime(1990, 04, 04), "Madrid", "Queen Cozinha", "Brazil", new DateTime(1996, 9, 11), "Avda. Azteca 123"));
                        order.Add(new OrdersDetails(code + 3, "ANTON", "333", 3, 4.3 * i, true, new DateTime(1957, 11, 30), "Cholchester", "Frankenversand", "Germany", new DateTime(1996, 10, 7), "Carrera 52 con Ave. Bolívar #65-98 Llano Largo"));
                        order.Add(new OrdersDetails(code + 4, "BLONP", "444", 4, 5.3 * i, false, new DateTime(1930, 10, 22), "Marseille", "Ernst Handel", "Austria", new DateTime(1996, 12, 30), "Magazinweg 7"));
                        order.Add(new OrdersDetails(code + 5, "BOLID", "555", 5, 6.3 * i, true, new DateTime(1953, 02, 18), "Tsawassen", "Hanari Carnes", "Switzerland", new DateTime(1997, 12, 3), "1029 - 12th Ave. S."));
                        code += 5;
                    }
                }
                return order;
            }

            public int? OrderID { get; set; }
            public string CustomerID { get; set; }
            public string UserID { get; set; }
            public int? EmployeeID { get; set; }
            public double? Freight { get; set; }
            public string ShipCity { get; set; }
            public bool Verified { get; set; }
            public DateTime OrderDate { get; set; }

            public string ShipName { get; set; }

            public string ShipCountry { get; set; }

            public DateTime ShippedDate { get; set; }
            public string ShipAddress { get; set; }
        }

        public class Child
        {
            public static List<Child> childs = new List<Child>();
            public Child()
            {

            }
            public Child(int OrderID, int EmployeeID, string FirstName, string LastName)
            {
                this.OrderID = OrderID;
                this.EmployeeID = EmployeeID;
                this.FirstName = FirstName;
                this.LastName = LastName;
            }
            public static List<Child> GetAllRecords()
            {
                if (childs.Count() == 0)
                {
                    int code = 10000;
                    for (int i = 1; i < 2; i++)
                    {
                        childs.Add(new Child(code + 1, 1, "John", "Nicholas"));
                        childs.Add(new Child(code + 2, 2, "Robert", "Jerrick"));
                        childs.Add(new Child(code + 3, 3, "Vinet", "Hanar"));
                        childs.Add(new Child(code + 4, 4, "Tomps", "Robert"));
                        childs.Add(new Child(code + 5, 5, "Hanar", "Nancy"));
                        code += 5;
                    }
                }
                return childs;
            }
            public int? OrderID { get; set; }
            public int? EmployeeID { get; set; }
            public string FirstName { get; set; }
            public string LastName { get; set; }
        }
    }
}
