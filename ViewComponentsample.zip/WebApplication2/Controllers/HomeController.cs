﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Syncfusion.EJ2.Base;
using System.Collections;
using System.Diagnostics;
using System.Xml.Linq;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    public class PriorityListViewComponent : ViewComponent
    {
        public async Task<IViewComponentResult> InvokeAsync(
            int maxPriority, bool isDone)
        {
            string MyView = "Default";
            // If asking for all completed tasks, render with the "PVC" view.
            if (maxPriority > 3 && isDone == true)
            {
                MyView = "PVC";
            }
            string content = await DownloadDocsMainPageAsync();
            return View("PVC");
        }



        private async Task<string> DownloadDocsMainPageAsync()
        {
            await Task.Delay(1000);
            return "one";
        }
    }
    public class HomeController : Controller
    {
        public static List<OrdersDetails> orddata = new List<OrdersDetails>();
        public static List<Employee1Details> empdata = new List<Employee1Details>();

        //public IActionResult Index()
        //{
        //    ViewBag.dddata = OrdersDetails.GetAllRecords().ToList();
        //    ViewBag.empdata = Employee1Details.GetAllRecords().ToList();
        //    ViewBag.unitmixes = new string[] { "1", "2", "3", "4" };
        //    ViewBag.value = "Denmark";
        //    return View();
        //}

        public IActionResult Index()
        {
            ViewBag.dddata = OrdersDetails.GetAllRecords().ToList();
            ViewBag.empdata = Employee1Details.GetAllRecords().ToList();
            ViewBag.unitmixes = new string[] { "1", "2", "3", "4" };
            ViewBag.value = "Denmark";
            return View();
        }

        private async Task<string> DownloadDocsMainPageAsync()
        {
            await Task.Delay(1000);
            return "one";
        }


        public IActionResult Privacy(string value)
        {
            ViewData["Message"] = "Your application description page.";
            var id = Int32.Parse(value);
            var data = OrdersDetails.GetAllRecords();
            var filtered = data.FindAll(e => e.EmployeeID == id);
            ViewBag.dddata = filtered.ToList();
            return ViewComponent("PriorityList");
        }
        public class Employee1Details
        {
            public static List<Employee1Details> order = new List<Employee1Details>();
            public Employee1Details()
            {

            }
            public Employee1Details(int EmployeeId, string FirstName, string LastName, int ReportsTO)
            {
                this.EmployeeID = EmployeeId;
                this.FirstName = FirstName;
                this.LastName = LastName;
                this.ReportsTo = ReportsTo;
            }
            public static List<Employee1Details> GetAllRecords()
            {
                if (order.Count() == 0)
                {
                    for (int i = 1; i < 2; i++)
                    {
                        order.Add(new Employee1Details(i + 0, "Nancy", "Davolio", i + 0));
                        order.Add(new Employee1Details(i + 1, "Andrew", "Fuller", i + 3));
                        order.Add(new Employee1Details(i + 2, "Janet", "Leverling", i + 2));
                        order.Add(new Employee1Details(i + 3, "Margaret", "Peacock", i + 1));

                    }
                }
                return order;
            }


            public int? EmployeeID { get; set; }
            public string FirstName { get; set; }
            public string LastName { get; set; }
            public int? ReportsTo { get; set; }
            public string key { get; set; }
        }

        public class OrdersDetails
        {
            public static List<OrdersDetails> order = new List<OrdersDetails>();
            public OrdersDetails()
            {

            }
            public OrdersDetails(string OrderID, string CustomerId, int EmployeeId, double Freight, bool Verified, DateTime OrderDate, string ShipCity, string ShipName, string ShipCountry, DateTime ShippedDate, string ShipAddress)
            {
                this.OrderID = OrderID;
                this.CustomerID = CustomerId;
                this.EmployeeID = EmployeeId;
                this.Freight = Freight;
                this.ShipCity = ShipCity;
                this.Verified = Verified;
                this.OrderDate = OrderDate;
                this.ShipName = ShipName;
                this.ShipCountry = ShipCountry;
                this.ShippedDate = ShippedDate;
                this.ShipAddress = ShipAddress;
            }
            public static List<OrdersDetails> GetAllRecords()
            {
                if (order.Count() == 0)
                {
                    int code = 10;
                    for (int i = 1; i < 2; i++)
                    {
                        order.Add(new OrdersDetails(code + "1", "AL@FKI", i + 0, 2.3 * i, false, new DateTime(1991, 05, 15), "Berlin", "Simons bistro", "Denmark", new DateTime(1996, 7, 16), "Kirchgasse 6"));
                        order.Add(new OrdersDetails(code + "2", "AN!ATR", i + 2, 3.3 * i, true, new DateTime(1990, 04, 04), "Madrid", "Queen Cozinha", "Brazil", new DateTime(1996, 9, 11), "Avda. Azteca 123"));
                        order.Add(new OrdersDetails(code + "3", "#$ANTON", i + 1, 4.3 * i, true, new DateTime(1957, 11, 30), "Cholchester", "Frankenversand", "Germany", new DateTime(1996, 10, 7), "Carrera 52 con Ave. Bolívar #65-98 Llano Largo"));
                        order.Add(new OrdersDetails(code + "4", "BLO%NP", i + 3, 5.3 * i, false, new DateTime(1930, 10, 22), "Marseille", "Ernst Handel", "Austria", new DateTime(1996, 12, 30), "Magazinweg 7"));
                        order.Add(new OrdersDetails(code + "5", "BO^&LID", i + 4, 6.3 * i, true, new DateTime(1953, 02, 18), "Tsawassen", "Hanari Carnes", "Switzerland", new DateTime(1997, 12, 3), "1029 - 12th Ave. S."));
                        code += 5;
                    }
                }
                return order;
            }

            public string OrderID { get; set; }
            public string CustomerID { get; set; }
            public int? EmployeeID { get; set; }
            public double? Freight { get; set; }
            public string ShipCity { get; set; }
            public bool Verified { get; set; }
            public DateTime OrderDate { get; set; }

            public string ShipName { get; set; }

            public string ShipCountry { get; set; }

            public DateTime ShippedDate { get; set; }
            public string ShipAddress { get; set; }
        }
    }
}